import { Component, OnInit } from '@angular/core';
import { parseJwt } from '../Shared/jwtutils';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.scss'],
  standalone: true,
})
export class GreetingComponent implements OnInit {
  username: string = '';
  greetingMessage: string = '';

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    const tokenData = token ? parseJwt(token) : null;
    this.username = tokenData?.sub.toUpperCase() || 'Guest';
    this.greetingMessage = this.getGreeting();
  }

  private getGreeting(): string {
    const hours = new Date().getHours();
    if (hours < 12) return 'Good Morning';
    if (hours < 18) return 'Good Afternoon';
    return 'Good Evening';
  }
}
