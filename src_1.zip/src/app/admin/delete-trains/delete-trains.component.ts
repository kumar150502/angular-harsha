import { CommonModule } from '@angular/common';
import {
  HttpClient,
  HttpClientModule,
  HttpHeaders,
} from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-trains',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './delete-trains.component.html',
  styleUrls: ['./delete-trains.component.scss'],
})
export class DeleteTrainsComponent implements OnInit {
  trains: any[] = [];
  error: string | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchAllTrains();
  }

  fetchAllTrains(): void {
    const token = localStorage.getItem('token');

    if (!token) {
      this.error = 'Authorization token is missing. Please log in again.';
      return;
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.http
      .get<any[]>('http://localhost:8080/Trains/user/getAll', { headers })
      .subscribe({
        next: (data) => (this.trains = data),
        error: (error) => {
          if (error.status === 401 || error.status === 403) {
            this.error = 'Unauthorized. Please login again.';
          } else {
            this.error = 'Failed to fetch trains.';
          }
          console.error('Error fetching trains:', error);
        },
      });
  }

  handleDelete(trainNumber: string): void {
    if (
      !window.confirm(
        `Are you sure you want to delete train number ${trainNumber}?`
      )
    )
      return;

    const token = localStorage.getItem('token');
    if (!token) {
      this.error = 'Authorization token is missing. Please log in again.';
      return;
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.http
      .delete('http://localhost:8080/Trains/delete/' + trainNumber, {
        headers,
        responseType: 'text', // Make sure the response is treated as a plain string
      })
      .subscribe({
        next: (response: string) => {
          // Handle the successful response
          if (response === 'Train deleted successfully') {
            this.trains = this.trains.filter(
              (train) => train.trainNumber !== trainNumber
            );
            alert(response); // Show success alert
          } else {
            this.error = 'Failed to delete train.';
          }
        },
        error: (error) => {
          // If there's an error, log it and show an appropriate message
          console.error('Error deleting train:', error);
          this.error = `Failed to delete train. Error: ${
            error.message || error.statusText || 'Unknown error'
          }`;
        },
      });
  }
}
