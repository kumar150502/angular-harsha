import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: '',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {}
