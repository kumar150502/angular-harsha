import { Component, OnInit } from '@angular/core';
import axios from 'axios';
import { parseJwt } from '../../Shared/jwtutils'; 
import { HttpClient, HttpClientModule } from '@angular/common/http';// Adjust the path as necessary
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-transaction',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss'],
})
export class TransactionComponent implements OnInit {
  orders = [];
  loading = true;
  error: string | null = null;
  userId: string | undefined;

  ngOnInit(): void {
    // Get the userId from token
    const token = localStorage.getItem('token');
    const tokenData = parseJwt(token);
    this.userId = tokenData?.id;

    this.fetchOrders();
  }

  fetchOrders(): void {
    if (!this.userId) {
      this.error = 'User ID is missing';
      this.loading = false;
      return;
    }

    const token = localStorage.getItem('token');

    axios
      .get(`http://localhost:8080/Payment/user/transactions/${this.userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        this.orders = response.data;
      })
      .catch((err) => {
        this.error = err.response ? err.response.data : 'An error occurred';
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
