import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
declare var Razorpay: any;

@Component({
  selector: 'app-train-booking',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule],
  templateUrl: './train-booking.component.html',
  styleUrls: ['./train-booking.component.scss'],
})
export class TrainBookingComponent implements OnInit {
  trainNumberInput: string = '';
  passengers: number = 1;
  selectedTrain: any = null;
  error: string | null = null;
  loading: boolean = false;
  bookingError: string | null = null;
  paymentSuccess: string | null = null;
  private baseUrl = 'http://localhost:8080/Bookings/user';
  private paymentUrl = 'http://localhost:8080/Payment/user';

  private token: string | null = localStorage.getItem('token');
  private user: any = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Load Razorpay script
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);

    if (this.token) {
      const tokenData = this.parseJwt(this.token);
      if (tokenData && tokenData.id !== undefined) {
        this.user = {
          id: tokenData.id,
          name: tokenData.sub || 'User Name',
          email: tokenData.email || 'user@example.com',
        };
      } else {
        this.error = 'Invalid token or missing user data in token.';
      }
    } else {
      this.error = 'Token not found. Please log in again.';
    }
  }

  private parseJwt(token: string): any {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const parsedData = JSON.parse(window.atob(base64));
      return parsedData;
    } catch (error) {
      console.error('Error parsing JWT:', error);
      return null;
    }
  }

  fetchTrainDetails(): void {
    if (!this.trainNumberInput || !/^\d+$/.test(this.trainNumberInput)) {
      this.error = 'Please enter a valid train number.';
      return;
    }

    this.loading = true;
    const headers = new HttpHeaders({ Authorization: `Bearer ${this.token}` });

    this.http.get(`${this.baseUrl}/train/${this.trainNumberInput}`, { headers }).subscribe({
      next: (data: any) => {
        this.selectedTrain = {
          trainNumber: data.trainNumber || 'N/A',
          source: data.source || 'Unknown',
          destination: data.destination || 'Unknown',
          fare: data.fare || 'N/A',
          arrivalTime: data.arrivalTime || 'N/A',
          departureTime: data.departureTime || 'N/A',
        };
        this.error = null;
      },
      error: (error) => {
        this.error = 'Failed to load train details. Please try again later.';
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  async handlePayment(): Promise<void> {
    if (!this.selectedTrain || this.passengers < 1 || this.passengers > 4) {
      this.error = 'Please select between 1 to 4 passengers.';
      return;
    }

    try {
      const orderData = {
        name: this.user.name,
        email: this.user.email,
        amount: this.selectedTrain.fare * this.passengers,
        userid: this.user.id
      };

      const headers = new HttpHeaders({ 
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      });

      // Create order
      const orderResponse: any = await this.http.post(
        `${this.paymentUrl}/createOrder`, 
        orderData, 
        { headers }
      ).toPromise();

      const options = {
        key: "rzp_test_GGqgmFBLIg33LX",
        amount: orderResponse.amount * 100,
        currency: "INR",
        name: "Train Booking",
        description: `Booking for ${this.selectedTrain.trainNumber}`,
        order_id: orderResponse.razorpayOrderId,
        prefill: {
          name: orderResponse.name,
          email: orderResponse.email,
          userid: orderResponse.userid,
        },
        theme: {
          color: "#339900"
        },
        handler: async (paymentResponse: any) => {
          try {
            // Handle payment callback
            const callbackResponse: any = await this.http.post(
              `${this.paymentUrl}/paymentCallback`,
              paymentResponse,
              { headers }
            ).toPromise();

            if (callbackResponse === "Payment Successful") {
              // Create booking
              const bookingData = {
                userId: this.user.id,
                trainId: this.selectedTrain.trainNumber,
                noOfSeats: this.passengers
              };

              const bookingResponse = await this.http.post(
                `${this.baseUrl}/bookTicket`,
                bookingData,
                { headers }
              ).toPromise();

              if (bookingResponse) {
                this.paymentSuccess = 'Booking confirmed! Your ticket has been booked successfully.';
                this.bookingError = null;
              } else {
                this.bookingError = 'Failed to book ticket.';
              }
            } else {
              this.bookingError = 'Payment processing failed.';
            }
          } catch (error) {
            console.error('Error during payment callback:', error);
            this.bookingError = 'An error occurred during payment processing.';
          }
        }
      };

      const rzp = new Razorpay(options);
      rzp.open();

    } catch (error) {
      console.error('Error during payment process:', error);
      this.bookingError = 'Failed to initiate payment. Please try again.';
    }
  }
}