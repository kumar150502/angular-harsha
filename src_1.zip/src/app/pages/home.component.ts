import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <div class="app">
      <div class="background">
        <!-- Background content -->
      </div>
      <div
        style="
          position: relative;
          z-index: 2;
          display: flex;
          justify-content: center;
          align-items: flex-start;
          min-height: 100vh;
        "
      >
        <h1>Welcome to the Railway Reservation System</h1>
      </div>
    </div>
  `,
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {}
