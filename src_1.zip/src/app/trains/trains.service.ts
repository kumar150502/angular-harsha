import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root', // Register the service in the root injector
})
export class TrainsService {
  private baseUrl = 'http://localhost:8080/Trains/user';

  constructor(private http: HttpClient) {} // Ensure HttpClient is properly injected

  getAllTrains(token: string): Observable<any> {
    console.log('Fetching all trains...');
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
    return this.http.get(`${this.baseUrl}/getAll`, { headers }).pipe(
      tap((data) => console.log('Trains fetched successfully:', data)),
      catchError((error) => {
        console.error('Error fetching trains:', error);
        return throwError(() => new Error('Failed to fetch trains.'));
      })
    );
  }

  searchTrains(
    token: string,
    source: string,
    destination: string
  ): Observable<any> {
    console.log(`Searching trains from "${source}" to "${destination}"...`);
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });
    const params = { source, destination };
    return this.http
      .get(`${this.baseUrl}/searchByStation`, { headers, params })
      .pipe(
        tap((data) => console.log('Search results:', data)),
        catchError((error) => {
          console.error('Error searching trains:', error);
          return throwError(() => new Error('Error searching trains.'));
        })
      );
  }
}
